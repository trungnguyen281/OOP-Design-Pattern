﻿namespace SCOFramework
{
    public enum DataType
    {
        INT,
        FLOAT,
        CHAR,
        NCHAR,
        VARCHAR,
        NVARCHAR,
        BOOL
    }
}
